clear;clc;close; dbstop if error
ni=11; nj=6; 
x=linspace(0,2,ni); y=linspace(0,1,nj); h=x(2)-x(1);
[X,Y]=meshgrid(x,y);

b1=@(i,j) i==1; b3=@(i,j) i==ni;
b2=@(i,j) j==1; b4=@(i,j) j==nj;
dirichlet=@(i,j) b1(i,j) | b2(i,j) | b3(i,j) | b4(i,j);
node=@(i,j) [i(~dirichlet(i,j)); j(~dirichlet(i,j))];
stencil = @(i,j) [node(i,j) node(i-1,j) node(i+1,j) node(i,j-1) node(i,j+1)];
v=[4 -1 -1 -1 -1]
n=(ni-2)*(nj-2); A = sparse(n,n);
siz=[ni-2 nj-2];
for k=1:n
    [i,j]=ind2sub(siz,k);
    s=stencil(i+1,j+1);
    ind=sub2ind(siz,s(1,:)-1,s(2,:)-1);
    A(k,ind)=v(1:numel(ind));
end
b=ones(n,1)*h^2;
z=A\b;
Z=zeros(size(X));
Z(2:nj-1,2:ni-1)=reshape(z,siz)';

surf(X,Y,Z);
full(A)




