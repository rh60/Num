clear;clc;close; dbstop if error
ni=11; nj=6; 
x=linspace(0,2,ni); y=linspace(0,1,nj); h=x(2)-x(1);
[X,Y]=meshgrid(x,y);
x=X(2:nj-1,2:ni-1);x=x(:);
y=Y(2:nj-1,2:ni-1);y=y(:);
n=numel(x);
hold on
scatter(X(:),Y(:));
text(x,y,int2str((1:n)'));