clear;clc;close;
x=0;y=0;z=0; 
n=20;
g=@(x) cos(5*x)/3+sin(3*x)/5;
for i=1:n
    r=i/n;
    nj=6*i;
    for j=0:nj-1
        ph = 2*pi*j/nj; 
        x = [x r*cos(ph)];
        y = [y r*sin(ph)];
        z = [z r*g(ph)];
    end
end
tri=delaunay(x,y);
trisurf(tri,x,y,z);
axis equal;
