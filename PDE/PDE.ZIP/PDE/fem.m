clear; clc; close;
a=2;b=1;
g=Rectg(0,0,2,1);
[p,e,t]=initmesh(g,'hmax',0.25);
pdeplot(p,e,t);
hold on

for i=1:2%size(t,2)
    h=circumcircle(p(:,t(1:3,i)),1);
    pause(1)
    delete(h);
end

close

x=p(1,:); y=p(2,:); 
z=zeros(size(x));
tri=t(1:3,:)';
bdry = @(i) x(i)==0 ||  y(i)==0 || x(i)==a ||  y(i)==b;

for i=1:numel(x)
    if ~bdry(i)
        z(:)=0;
        z(i)=1;
        h=trimesh(tri,x,y,z);
        pause(1)
        delete(h);
    end
end

close